<h1>
	My first swelt component
</h1>

<p>
	heloo world
</p>
<a href= "google.com">link to my channel</a>
<style>
	h1{
	color: red;
	}
	p{
		font-size:55px;
	}
</style>

<scriopt>
	let name = "shashank"
</scriopt>

<scriopt>
	let name = "shashank"
</scriopt>